var t={INGRESO:"ingreso",EGRESO:"egreso"};export{t as a};
