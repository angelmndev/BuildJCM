var T=/^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/,E=/^\d*\.?\d+$/,A=/^[a-zA-Z0-9\s]+$/,_=/^(?!\s).*/;export{T as a,E as b,A as c,_ as d};
