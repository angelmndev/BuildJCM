var o=function(r){return r.cash="cash",r.transfer="transfer",r.more="more",r}(o||{});export{o as a};
